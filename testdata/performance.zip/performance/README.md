```
npm install
gauge run -v specs
```